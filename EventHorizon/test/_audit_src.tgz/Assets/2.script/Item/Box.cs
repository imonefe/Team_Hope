﻿using UnityEngine;

public class Box : ProximityInteractable
{
    [Header("스폰 포인트")]
    public Transform spawnPoint;

    [Header("드랍 아이템 목록")]
    public GameObject[] itemPrefabs;

    [Header("스킬 + 무기 드랍 (선택 — 켜면 위 itemPrefabs 대신 이쪽을 사용)")]
    [Tooltip("켜면 DropItem() 시 itemPrefabs에서 하나 뽑는 대신, 아래 두 목록에서 각각 하나씩 뽑아 " +
             "스킬은 왼쪽으로, 무기는 오른쪽으로 동시에 튕겨져 나온다.")]
    public bool dropSkillAndWeapon = false;
    [Tooltip("SkillPickup 컴포넌트가 붙은 프리팹들 (왼쪽으로 드랍)")]
    public GameObject[] skillPickupPrefabs;
    [Tooltip("Weapon 컴포넌트가 붙은 프리팹들 (오른쪽으로 드랍)")]
    public GameObject[] weaponPickupPrefabs;

    [Header("아이템 튀어오르는 힘")]
    public float launchForceX = 2f;
    public float launchForceY = 6f;

    [Header("애니메이션")]
    public Animator animator;
    public string openTrigger = "Open";

    [Header("콜라이더")]
    public Collider2D interactCollider;

    bool isActive = false;
    bool isOpened = false;

    void Awake()
    {
        SetActive(false);
    }

    public void SetActive(bool value)
    {
        isActive = value;
        isOpened = false;
        if (interactCollider != null)
            interactCollider.enabled = isActive;
    }

    // [2026-09-29 변경] Player 태그 감지 + F키 입력 처리(Update/OnTrigger)는 공용 베이스
    // ProximityInteractable로 이동. 여기서는 "지금 열 수 있는 상태인가"만 판단한다.
    protected override bool CanInteract() => isActive && !isOpened;

    protected override void Interact()
    {
        OpenBox();
    }

    void OpenBox()
    {
        Debug.Log("[Box] OpenBox 호출!");
        isOpened = true;
        if (animator != null)
        {
            Debug.Log($"[Box] SetTrigger: {openTrigger}");
            animator.SetTrigger(openTrigger);
        }
        else Debug.LogWarning("[Box] Animator 없음!");
    }

    // 애니메이션 이벤트에서 호출
    public void DropItem()
    {
        Vector3 pos = spawnPoint != null ? spawnPoint.position : transform.position;

        if (dropSkillAndWeapon)
        {
            LaunchOne(skillPickupPrefabs, pos, -1); // 스킬 — 왼쪽
            LaunchOne(weaponPickupPrefabs, pos, 1);  // 무기 — 오른쪽
            return;
        }

        GameObject item = SpawnUtil.InstantiateRandom(itemPrefabs, pos);
        if (item == null) return;

        Rigidbody2D rb = item.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            float randX = Random.Range(-launchForceX, launchForceX);
            rb.AddForce(new Vector2(randX, launchForceY), ForceMode2D.Impulse);
        }
    }

    // prefabs 중 하나를 랜덤으로 뽑아 pos에 생성하고, dir 방향(-1=왼쪽/1=오른쪽)으로 튕겨낸다.
    void LaunchOne(GameObject[] prefabs, Vector3 pos, int dir)
    {
        GameObject spawned = SpawnUtil.InstantiateRandom(prefabs, pos);
        if (spawned == null) return;

        Rigidbody2D rb = spawned.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            float x = Random.Range(launchForceX * 0.5f, launchForceX) * dir;
            rb.AddForce(new Vector2(x, launchForceY), ForceMode2D.Impulse);
        }
    }
}
