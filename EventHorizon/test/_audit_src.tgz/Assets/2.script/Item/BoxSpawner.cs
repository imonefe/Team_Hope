﻿using UnityEngine;

/// <summary>
/// Room.cs 에서 SetActive(true) 호출 시
/// 스폰 포인트 위에 박스 소환
/// </summary>
public class BoxSpawner : MonoBehaviour
{
    [Header("설정")]
    public GameObject[] boxPrefabs;  // 4개 등록
    public Transform spawnPoint;

    [Header("스폰 이펙트 (선택)")]
    public GameObject spawnEffectPrefab;
    public Transform effectPoint;  // 비우면 spawnPoint 위치 사용

    GameObject spawnedBox;

    public void SetActive(bool value)
    {
        if (value)
            Spawn();
        else
            Despawn();
    }

    void Spawn()
    {
        if (spawnedBox != null) return;

        Vector3 pos = spawnPoint != null ? spawnPoint.position : transform.position;
        spawnedBox = SpawnUtil.InstantiateRandom(boxPrefabs, pos);
        if (spawnedBox == null) return;

        spawnedBox.transform.SetParent(transform, true);

        // 스폰 이펙트 (상자 나오는 자리 가리기용)
        if (spawnEffectPrefab != null)
        {
            Vector3 fxPos = effectPoint != null ? effectPoint.position : pos;
            Instantiate(spawnEffectPrefab, fxPos, Quaternion.identity);
        }

        // 박스 활성화
        Box box = spawnedBox.GetComponent<Box>();
        if (box != null) box.SetActive(true);
    }

    void Despawn()
    {
        if (spawnedBox != null)
        {
            Destroy(spawnedBox);
            spawnedBox = null;
        }
    }
}
