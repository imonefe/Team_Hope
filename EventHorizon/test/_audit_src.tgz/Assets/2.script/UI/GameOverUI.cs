using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// 게임오버 화면. CharacterManager.GameOver()가 Show()를 호출해서 활성화하고,
/// 이번 런의 통계(플레이타임/처치한 적·보스/해결한 스테이지/최종 스텟/보유 재화)를 채워 보여준다.
/// "다시하기" 버튼은 이 스크립트가 알아서 RunManager.RestartRun()에 연결한다.
/// </summary>
public class GameOverUI : MonoBehaviour
{
    public static GameOverUI Instance;

    [Header("텍스트 필드 (비워두면 그 항목은 표시 안 함)")]
    public TMP_Text playTimeText;
    public TMP_Text enemiesKilledText;
    public TMP_Text bossesKilledText;
    public TMP_Text stageText;
    public TMP_Text statsText;
    public TMP_Text currencyText;

    [Header("버튼")]
    public Button retryButton;

    void Awake()
    {
        Instance = this;
        gameObject.SetActive(false);

        if (retryButton != null)
            retryButton.onClick.AddListener(OnRetryClicked);

        // 버튼 호버/클릭 연출 + 게임오버 화면 등장 애니메이션
        UIButtonJuice.Attach(retryButton);
        if (GetComponent<UIPanelAnimator>() == null)
            gameObject.AddComponent<UIPanelAnimator>();
    }

    /// <summary>게임오버 시 CharacterManager.GameOver()에서 호출. finalStats는 마지막으로 죽은 캐릭터의 Stats.</summary>
    public void Show(Stats finalStats)
    {
        gameObject.SetActive(true);
        Time.timeScale = 0f;

        float playTime = RunManager.Instance != null ? RunManager.Instance.GetPlayTime() : 0f;
        int enemies = RunManager.Instance != null ? RunManager.Instance.EnemiesKilled : 0;
        int bosses = RunManager.Instance != null ? RunManager.Instance.BossesKilled : 0;
        int stage = MapManager.Instance != null ? MapManager.Instance.CurrentStageIndex + 1 : 1;
        int currency = RunManager.Instance != null ? RunManager.Instance.Amount : 0;

        if (playTimeText != null) playTimeText.text = $"플레이 타임   {RunManager.FormatTime(playTime)}";
        if (enemiesKilledText != null) enemiesKilledText.text = $"처치한 적   {enemies}";
        if (bossesKilledText != null) bossesKilledText.text = $"처치한 보스   {bosses}";
        if (stageText != null) stageText.text = $"해결한 스테이지   {stage}";
        if (currencyText != null) currencyText.text = $"보유 재화   {currency}";

        if (statsText != null)
        {
            statsText.text = finalStats != null
                ? $"공격력 {finalStats.Atk:0}   방어력 {finalStats.Def:0}   " +
                  $"이동속도 {finalStats.spd:0.0}   집중력 {finalStats.Focus:0}   " +
                  $"치명타 확률 {finalStats.critChance * 100f:0}%"
                : "스탯 정보 없음";
        }
    }

    void OnRetryClicked()
    {
        Time.timeScale = 1f;
        RunManager.RestartRun();
    }
}
