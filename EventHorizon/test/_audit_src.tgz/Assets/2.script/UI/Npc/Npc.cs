using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections;
using System.Linq;

public class NPC : MonoBehaviour
{
    [Header("텍스트 설정")]
    public TextMeshProUGUI textComponent;
    public float textSpeed = 0.05f;

    [Header("UI 캔버스")]
    public GameObject dialogueCanvas;
    public GameObject nextCanvasPrefab;   // 대화 후 띄울 상점/스탯 캔버스

    [Header("초상화")]
    public Image[] portraits;

    [Header("대사 세트")]
    public DialogueSet[] dialogueSets;

    [Header("컷신 (선택)")]
    public GameObject[] cutscenes;
    public int[] cutsceneStartLines;
    public int[] cutsceneEndLines;

    private string[] lines;
    private int[] speakers;
    private int index = 0;
    private bool dialogueStarted = false;
    private bool justStarted = false;
    private PlayerController currentPlayer;

    public bool IsTalking => dialogueStarted;

    [System.Serializable]
    public class DialogueSet
    {
        public string conditionKey;

        [TextArea(2, 10)]
        public string[] lines;

        [Tooltip("각 줄을 누가 말하는지 (portraits 인덱스)")]
        public int[] speakerIndex;
    }

    public void SetCondition(string condition = null, PlayerController player = null)
    {
        DialogueSet targetSet = string.IsNullOrEmpty(condition)
            ? dialogueSets.FirstOrDefault()
            : dialogueSets.FirstOrDefault(d => d.conditionKey == condition);

        if (targetSet != null)
        {
            lines = targetSet.lines;
            speakers = targetSet.speakerIndex;
            index = 0;
            StartDialogue(player);
        }
    }

    public void StartDialogue(PlayerController player)
    {
        currentPlayer = player;

        if (lines == null || lines.Length == 0) return;

        bool alreadyOpen = dialogueStarted;
        dialogueStarted = true;
        justStarted = true;

        // 플레이어 조작 잠금
        if (currentPlayer != null)
            currentPlayer.LockControl();

        if (dialogueCanvas != null)
            dialogueCanvas.SetActive(true);

        // 대화가 시작될 때 전투 UI를 잠근다 (이미 대화 중이었다면 중복으로 잠그지 않음)
        if (!alreadyOpen)
            CombatUIGate.Block();

        UpdatePortraits();
        StopAllCoroutines();
        StartCoroutine(TypeLine());
    }

    void Update()
    {
        if (!dialogueStarted || lines == null || lines.Length == 0) return;

        // 시작 첫 프레임은 입력 무시 (트리거 F가 다음 줄로 새는 것 방지)
        if (justStarted) { justStarted = false; return; }

        // F 또는 마우스 클릭으로 다음 줄
        if (Input.GetKeyDown(KeyCode.F) || Input.GetMouseButtonDown(0))
        {
            string line = lines[index].Replace("\\n", "\n");

            if (textComponent.text == line)
                NextLine();
            else
            {
                StopAllCoroutines();
                textComponent.text = line;
            }
        }
    }

    IEnumerator TypeLine()
    {
        string line = lines[index].Replace("\\n", "\n");
        textComponent.text = "";

        foreach (char c in line)
        {
            textComponent.text += c;
            yield return new WaitForSeconds(textSpeed);
        }
    }

    void NextLine()
    {
        if (index < lines.Length - 1)
        {
            index++;
            HandleCutscene(index);
            UpdatePortraits();
            StopAllCoroutines();
            StartCoroutine(TypeLine());
        }
        else
        {
            EndDialogue();
        }
    }

    void EndDialogue()
    {
        dialogueStarted = false;
        lines = null;

        if (dialogueCanvas != null)
            dialogueCanvas.SetActive(false);

        // 대화가 끝나면 전투 UI 잠금을 해제한다.
        CombatUIGate.Unblock();

        // 대화 후 상점/스탯 캔버스 띄우기
        if (nextCanvasPrefab != null)
            Instantiate(nextCanvasPrefab, Vector3.zero, Quaternion.identity);

        // 조작 복원
        if (currentPlayer != null)
            currentPlayer.ResumeControl();
    }

    void HandleCutscene(int lineIndex)
    {
        if (cutscenes == null) return;

        for (int i = 0; i < cutsceneStartLines.Length; i++)
            if (cutsceneStartLines[i] == lineIndex && cutscenes[i] != null)
                cutscenes[i].SetActive(true);

        for (int i = 0; i < cutsceneEndLines.Length; i++)
            if (cutsceneEndLines[i] == lineIndex && cutscenes[i] != null)
                cutscenes[i].SetActive(false);
    }

    void UpdatePortraits()
    {
        if (portraits == null || portraits.Length == 0) return;
        if (speakers == null || speakers.Length == 0) return;

        int currentSpeaker = (index < speakers.Length) ? speakers[index] : 0;

        for (int i = 0; i < portraits.Length; i++)
        {
            float brightness = (i == currentSpeaker) ? 1f : 0.3f;
            portraits[i].color = new Color(brightness, brightness, brightness, 1f);
        }
    }
}
